/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examen_2018_2019_part_I;

import java.util.Objects;

/**
 *
 * @author gmartinez
 */

//OJO que a la declaració de la classe  li falta algo...
public class Meteorit{
    private Integer id;
    private Integer distancia;
    private String SistemaDeGuiaAssignat;

    
    Meteorit(int id, int distancia) {
        this.id = id;
        this.distancia = distancia;
        this.SistemaDeGuiaAssignat = "CAP";
    }

    
  
    
    
}
